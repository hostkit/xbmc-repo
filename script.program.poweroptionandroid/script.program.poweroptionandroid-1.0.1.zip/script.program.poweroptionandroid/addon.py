import xbmcgui
import xbmcaddon
import xbmc
import os

__settings__ = xbmcaddon.Addon(id='script.program.poweroptionandroid')
__power__ = __settings__.getSetting('powerop')
	
def shutdown():
	os.system("su -c 'reboot -p'")

def reboot():
	os.system("su -c 'reboot'")

if __power__ == "0":
	reboot()
elif __power__ == "1":
	shutdown()
