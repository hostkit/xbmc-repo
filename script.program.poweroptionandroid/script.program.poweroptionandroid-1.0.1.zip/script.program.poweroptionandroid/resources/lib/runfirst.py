import os

def checksu():
    os.system("su -c ''")
        
checksu()